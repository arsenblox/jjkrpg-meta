package me.arsenplugin.jjkrpg.meta;

/**
 * Denizen meta documentation for JJKRPG / JJKPort.
 * This class is only for Denizen VS Code / SharpDenizenTools meta scanning.
 */
public final class JJKPortMeta {

    private JJKPortMeta() {
    }

    // <--[ObjectType]
    // @name MEGModelTag
    // @prefix meg_model
    // @base ObjectTag
    // @ExampleTagBase player.target.active_models.get[naoya]
    // @ExampleValues <player.target.active_models.get[naoya]>
    // @ExampleForReturns
    // - narrate "Model ID: %VALUE%"
    // @format
    // The identity format is the base Bukkit entity UUID, followed by a pipe, followed by the ModelEngine model ID.
    //
    // For example:
    // meg_model@00000000-0000-0000-0000-000000000000|naoya
    //
    // @description
    // A MEGModelTag represents one active ModelEngine model attached to a Bukkit entity.
    //
    // This object is returned by <@link tag EntityTag.active_models>.
    // Use this object to read the active model ID, list bones, or get one bone directly by ID.
    //
    // -->

    // <--[ObjectType]
    // @name MEGBoneTag
    // @prefix meg_bone
    // @base ObjectTag
    // @ExampleTagBase player.target.active_models.get[naoya].bone[head]
    // @ExampleValues <player.target.active_models.get[naoya].bone[head]>
    // @ExampleForReturns
    // - teleport <server.flag[eye_display]> %VALUE%
    // @format
    // The identity format is the base Bukkit entity UUID, followed by a pipe, followed by the ModelEngine model ID, followed by a pipe, followed by the bone ID.
    //
    // For example:
    // meg_bone@00000000-0000-0000-0000-000000000000|naoya|head
    //
    // @description
    // A MEGBoneTag represents one ModelEngine bone from an active model.
    //
    // This object is returned by <@link tag MEGModelTag.bones> and <@link tag MEGModelTag.bone>.
    // It is intended for safe external attachment workflows, such as teleporting a real item_display to a ModelEngine bone location.
    //
    // -->

    // <--[tag]
    // @attribute <EntityTag.active_models>
    // @returns MapTag
    // @Plugin JJKPort
    // @group modelengine
    // @description
    // Returns a map of active ModelEngine models attached to this entity.
    //
    // The map can be accessed by model ID:
    // <entity.active_models.get[naoya]>
    //
    // It can also be accessed by numeric index:
    // <entity.active_models.get[1]>
    //
    // Each map value is a MEGModelTag object.
    // If the entity is not spawned, has no ModelEngine wrapper, or has no active models, this returns an empty map.
    //
    // @example
    // # Gets a model by model ID.
    // - define modelname naoya
    // - define model <player.target.active_models.get[<[modelname]>]>
    // - narrate "Model: <[model].id>"
    //
    // @example
    // # Gets the first model by index.
    // - define model <player.target.active_models.get[1]>
    // - narrate "Model: <[model].id>"
    //
    // -->

    // <--[tag]
    // @attribute <MEGModelTag.id>
    // @returns ElementTag
    // @Plugin JJKPort
    // @group modelengine
    // @description
    // Returns the ModelEngine model ID of this active model.
    //
    // @example
    // - define model <player.target.active_models.get[1]>
    // - narrate "Model ID: <[model].id>"
    //
    // -->

    // <--[tag]
    // @attribute <MEGModelTag.bones>
    // @returns ListTag
    // @Plugin JJKPort
    // @group modelengine
    // @description
    // Returns a list of ModelEngine bones available on this active model.
    //
    // Each list entry is a MEGBoneTag object.
    //
    // @example
    // # Lists all bone IDs on the first active model of the targeted entity.
    // - foreach <player.target.active_models.get[1].bones> as:bone:
    //     - narrate "Bone: <[bone].id>"
    //
    // -->

    // <--[tag]
    // @attribute <MEGModelTag.bone[<bone_id>]>
    // @returns MEGBoneTag
    // @Plugin JJKPort
    // @group modelengine
    // @description
    // Returns a single ModelEngine bone from this active model by bone ID.
    //
    // This is the simple lookup form:
    // <entity.active_models.get[model_id].bone[bone_id]>
    //
    // @example
    // # Gets the head bone from a model by model name.
    // - define modelname naoya
    // - define bone <player.target.active_models.get[<[modelname]>].bone[head]>
    // - narrate "Bone location: <[bone].location>"
    //
    // -->

    // <--[tag]
    // @attribute <MEGModelTag.has_bone[<bone_id>]>
    // @returns ElementTag(Boolean)
    // @Plugin JJKPort
    // @group modelengine
    // @description
    // Returns whether this active model has the specified bone ID.
    //
    // @example
    // - define model <player.target.active_models.get[naoya]>
    // - if <[model].has_bone[head]>:
    //     - narrate "This model has a head bone."
    //
    // -->

    // <--[tag]
    // @attribute <MEGModelTag.bone_count>
    // @returns ElementTag(Number)
    // @Plugin JJKPort
    // @group modelengine
    // @description
    // Returns the number of bones available on this active model.
    //
    // @example
    // - define model <player.target.active_models.get[1]>
    // - narrate "Bone count: <[model].bone_count>"
    //
    // -->

    // <--[tag]
    // @attribute <MEGBoneTag.id>
    // @returns ElementTag
    // @Plugin JJKPort
    // @group modelengine
    // @description
    // Returns the bone ID.
    //
    // @example
    // - define bone <player.target.active_models.get[1].bone[head]>
    // - narrate "Bone ID: <[bone].id>"
    //
    // -->

    // <--[tag]
    // @attribute <MEGBoneTag.model_id>
    // @returns ElementTag
    // @Plugin JJKPort
    // @group modelengine
    // @description
    // Returns the ModelEngine model ID that owns this bone.
    //
    // @example
    // - define bone <player.target.active_models.get[1].bone[head]>
    // - narrate "Model ID: <[bone].model_id>"
    //
    // -->

    // <--[tag]
    // @attribute <MEGBoneTag.location>
    // @returns LocationTag
    // @Plugin JJKPort
    // @group modelengine
    // @description
    // Returns the current world location of this ModelEngine bone, when available.
    //
    // This is useful for attaching real Bukkit display entities to ModelEngine bones without editing ModelEngine's internal packet-rendered display entities.
    //
    // @example
    // - define bone <player.target.active_models.get[naoya].bone[head]>
    // - teleport <server.flag[eye_display]> <[bone].location>
    //
    // -->

    // <--[tag]
    // @attribute <MEGBoneTag.position>
    // @returns ListTag
    // @Plugin JJKPort
    // @group modelengine
    // @description
    // Returns the bone position vector as a list of three numbers, when available.
    //
    // The list order is x, y, z.
    //
    // @example
    // - define bone <player.target.active_models.get[naoya].bone[head]>
    // - narrate "Position: <[bone].position>"
    //
    // -->

    // <--[tag]
    // @attribute <MEGBoneTag.scale>
    // @returns ListTag
    // @Plugin JJKPort
    // @group modelengine
    // @description
    // Returns the bone scale vector as a list of three numbers, when available.
    //
    // The list order is x, y, z.
    //
    // @example
    // - define bone <player.target.active_models.get[naoya].bone[head]>
    // - narrate "Scale: <[bone].scale>"
    //
    // -->

    // <--[tag]
    // @attribute <MEGBoneTag.translation>
    // @returns ListTag
    // @Plugin JJKPort
    // @group modelengine
    // @description
    // Returns the bone translation vector as a list of three numbers, when available.
    //
    // The list order is x, y, z.
    //
    // @example
    // - define bone <player.target.active_models.get[naoya].bone[head]>
    // - narrate "Translation: <[bone].translation>"
    //
    // -->

    // <--[tag]
    // @attribute <MEGBoneTag.debug_pose>
    // @returns ElementTag
    // @Plugin JJKPort
    // @group modelengine
    // @description
    // Returns debug text about this bone's current transform lookup.
    //
    // This is intended for development and troubleshooting.
    //
    // @example
    // - define bone <player.target.active_models.get[naoya].bone[head]>
    // - narrate <[bone].debug_pose>
    //
    // -->

    // <--[command]
    // @Name Megattach
    // @Syntax megattach [<entity>|...] (to:<meg_bone>) (cancel) (pivot) (scale) (rotation) (smooth:<#>) (position_smooth:<#>) (rotation_smooth:<#>) (scale_smooth:<#>) (offset:<x,y,z>) (offset_yaw:<#>) (offset_pitch:<#>)
    // @Required 1
    // @Maximum 12
    // @Short Attaches real Bukkit entities to a ModelEngine bone.
    // @Group entity
    //
    // @Description
    // Attaches one or more real Bukkit entities to a ModelEngine bone by updating them to the bone location every tick.
    //
    // This is intended for safe external display attachment, for example attaching a real item_display with billboard:CENTER to a ModelEngine eye or VFX bone.
    //
    // Use "to:<meg_bone>" to choose the target bone.
    // Use "cancel", "stop", or "detach" to remove an existing attachment.
    // Use "pivot" to rotate the offset around the bone yaw.
    // Use "scale" to multiply a Display entity's original scale by the bone scale.
    // Use "rotation" to copy the bone yaw and pitch to the attached entity.
    // Use "offset:<x,y,z>" to add a position offset.
    // Use "offset_yaw:<#>" and "offset_pitch:<#>" to add rotation offsets. These imply "rotation".
    //
    // Smoothing options:
    // "smooth:<#>" applies the same fallback smoothing value to position, rotation, and scale.
    // "position_smooth:<#>" controls position smoothing.
    // "rotation_smooth:<#>" controls rotation smoothing.
    // "scale_smooth:<#>" controls scale smoothing.
    //
    // If the attached entity is removed, the base ModelEngine entity is removed, the model is removed, or the bone disappears, the attachment automatically cancels.
    //
    // @Tags
    // <EntityTag.active_models>
    // <MEGModelTag.bone>
    // <MEGBoneTag.location>
    // <MEGBoneTag.scale>
    // <MEGBoneTag.id>
    //
    // @Usage
    // Attach one item_display to a named bone from a named model.
    // - define bone <player.target.active_models.get[naoya].bone[head]>
    // - megattach <server.flag[eye_display]> to:<[bone]>
    //
    // @Usage
    // Attach with scaling and centered billboard.
    // - define bone <player.target.active_models.get[naoya].bone[head]>
    // - adjust <server.flag[eye_display]> billboard:CENTER
    // - megattach <server.flag[eye_display]> to:<[bone]> scale
    //
    // @Usage
    // Attach with local offset, rotation, and rotation offsets.
    // - define bone <player.target.active_models.get[naoya].bone[head]>
    // - megattach <server.flag[eye_display]> to:<[bone]> pivot scale rotation offset:0,0.05,0.1 offset_yaw:180 offset_pitch:0
    //
    // @Usage
    // Attach with one smoothing shortcut value.
    // - define bone <player.target.active_models.get[naoya].bone[head]>
    // - megattach <server.flag[eye_display]> to:<[bone]> pivot scale rotation smooth:2
    //
    // @Usage
    // Attach with separate smoothing values.
    // - define bone <player.target.active_models.get[naoya].bone[head]>
    // - megattach <server.flag[eye_display]> to:<[bone]> pivot scale rotation position_smooth:1 rotation_smooth:0 scale_smooth:2
    //
    // @Usage
    // Cancel an attachment.
    // - megattach <server.flag[eye_display]> cancel
    //
    // -->
}
